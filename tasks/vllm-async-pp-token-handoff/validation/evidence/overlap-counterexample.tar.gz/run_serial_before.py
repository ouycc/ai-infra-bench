from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import subprocess,json,shutil,time,hashlib
root=Path('/tmp/ai-infra-pr75-review/tasks/vllm-async-pp-token-handoff')
out=Path('/tmp/pr75-hardening-evidence/serial-executor-before')
out.mkdir(exist_ok=True)
snapshot=Path('/tmp/pr75-hardening-evidence/optimized-v4/task')
image='sha256:cf04408e8aed807333ff1522f952182aa7948f2a32e3caeee79dac9b95911e69'
cases=[{'name':'serial-executor','expected_reward':0,'apply_after':'oracle','patch':'serial-executor.patch'}]

def command(args,**kw):
 return subprocess.run(args,check=True,**kw)

def run(case):
 name=case['name']; dest=out/name;dest.mkdir(parents=True,exist_ok=True)
 container='pr75-serial-before-'+name
 began=time.time();result={'case':name,'expected_reward':case['expected_reward'],'image':image}
 try:
  command(['docker','run','-d','--name',container,'--network','none','--gpus','"device=1,3"','--cpus','8','--memory','32g','--shm-size','2g',
    '-v',str(snapshot/'tests')+':/tests:ro','-v',str(snapshot/'solution')+':/solution:ro',
    '-v',str(root/'validation')+':/controls:ro',image],stdout=subprocess.DEVNULL)
  if case.get('apply_after')=='oracle':
   command(['docker','exec','-u','agent',container,'bash','/solution/solve.sh'],stdout=subprocess.DEVNULL)
  if case.get('patch'):
   command(['docker','exec','-u','agent',container,'git','apply','/controls/'+case['patch']],stdout=subprocess.DEVNULL)
  with (dest/'entrypoint.log').open('w') as log:
   p=command(['docker','exec','-u','root',container,'bash','/tests/test.sh'],stdout=log,stderr=subprocess.STDOUT,timeout=1800)
   result['entrypoint_exit']=p.returncode
  command(['docker','cp',container+':/logs/verifier',str(dest/'verifier')],stdout=subprocess.DEVNULL)
  result['actual_reward']=int((dest/'verifier/reward.txt').read_text())
  m=json.loads((dest/'verifier/supervisor-manifest.json').read_text())
  result['stages']={k:v['satisfied'] for k,v in m['stages'].items()}
  result['matches_expected']=result['actual_reward']==case['expected_reward']
 except Exception as exc:
  result['error']=repr(exc)
 finally:
  subprocess.run(['docker','stop','-t','2',container],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  result['elapsed_seconds']=round(time.time()-began,1)
  (dest/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result),flush=True)
 return result

with ThreadPoolExecutor(max_workers=1) as pool:
 futures=[pool.submit(run,c) for c in cases]
 results=[f.result() for f in as_completed(futures)]
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
