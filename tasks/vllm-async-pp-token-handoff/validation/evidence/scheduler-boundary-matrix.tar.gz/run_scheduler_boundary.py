from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse,subprocess,json,shutil,time,hashlib,tarfile
SOURCE=Path('/tmp/ai-infra-pr75-review/tasks/vllm-async-pp-token-handoff')
CANDIDATE=Path('/data/ai-infra-evals/vllm-async-pp-astra-medium-apikey-fan-20260912T151928Z/jobs/astra-medium-apikey-fan-two-attempts/task-host-network__rruzoCB/artifacts/repo')
IMAGE='sha256:cf04408e8aed807333ff1522f952182aa7948f2a32e3caeee79dac9b95911e69'
parser=argparse.ArgumentParser()
parser.add_argument('--out',required=True)
parser.add_argument('--cases',nargs='+',default=['astra','oracle'])
parser.add_argument('--workers',type=int,default=2)
args=parser.parse_args()
out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
snapshot=out/'task'
if not snapshot.exists():shutil.copytree(SOURCE,snapshot,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
cases={c['name']:c for c in json.loads((snapshot/'validation/ci-cases.json').read_text())['cases']}
cases.update(oracle={'name':'oracle','expected_reward':1,'apply_after':'oracle'},base={'name':'base','expected_reward':0,'apply_after':'base'},astra={'name':'astra','expected_reward':None})
paths=subprocess.check_output(['git','-C',str(CANDIDATE),'diff','--name-only','HEAD'],text=True).splitlines()
paths+=subprocess.check_output(['git','-C',str(CANDIDATE),'ls-files','--others','--exclude-standard'],text=True).splitlines()
with tarfile.open(out/'candidate-overlay.tar','w') as tar:
 for name in paths:tar.add(CANDIDATE/name,arcname=name)
(out/'candidate-files.json').write_text(json.dumps({name:hashlib.sha256((CANDIDATE/name).read_bytes()).hexdigest() for name in paths},indent=2)+'\n')
(out/'executable-sha256.json').write_text(json.dumps({str(p.relative_to(snapshot)):hashlib.sha256(p.read_bytes()).hexdigest() for p in snapshot.rglob('*') if p.is_file()},indent=2)+'\n')
def command(cmd,**kw):return subprocess.run(cmd,check=True,**kw)
def run(name):
 case=cases[name];dest=out/name;dest.mkdir(exist_ok=True)
 container='pr75-'+out.name+'-'+name
 result={'case':name,'expected_reward':case['expected_reward'],'image':IMAGE,'snapshot':str(snapshot)}
 start=time.monotonic()
 try:
  command(['docker','run','-d','--name',container,'--network','none','--gpus','"device=0,2"','--cpus','8','--memory','32g','--shm-size','2g','-v',str(snapshot/'tests')+':/tests:ro','-v',str(snapshot/'solution')+':/solution:ro','-v',str(snapshot/'validation')+':/controls:ro',IMAGE],stdout=subprocess.DEVNULL)
  if name=='astra':
   command(['docker','cp',str(out/'candidate-overlay.tar'),container+':/tmp/candidate-overlay.tar'],stdout=subprocess.DEVNULL)
   command(['docker','exec','-u','agent',container,'tar','-xf','/tmp/candidate-overlay.tar','-C','/workspace/repo'],stdout=subprocess.DEVNULL)
  elif case.get('apply_after')=='oracle':
   command(['docker','exec','-u','agent',container,'bash','/solution/solve.sh'],stdout=subprocess.DEVNULL)
  if case.get('patch'):command(['docker','exec','-u','agent',container,'git','apply','/controls/'+case['patch']],stdout=subprocess.DEVNULL)
  with (dest/'entrypoint.log').open('w') as log:
   p=subprocess.run(['docker','exec','-u','root',container,'bash','/tests/test.sh'],stdout=log,stderr=subprocess.STDOUT,timeout=1800)
   result['entrypoint_exit']=p.returncode
  command(['docker','cp',container+':/logs/verifier',str(dest/'verifier')],stdout=subprocess.DEVNULL)
  result['actual_reward']=int((dest/'verifier/reward.txt').read_text())
  m=json.loads((dest/'verifier/supervisor-manifest.json').read_text())
  result['stages']={k:v['satisfied'] for k,v in m['stages'].items()}
  if case['expected_reward'] is not None:result['matches_expected']=result['actual_reward']==case['expected_reward']
 except Exception as exc:
  result['error']=repr(exc)
  subprocess.run(['docker','cp',container+':/logs/verifier',str(dest/'verifier')],capture_output=True)
 finally:
  subprocess.run(['docker','stop','-t','2',container],capture_output=True)
  result['elapsed_seconds']=round(time.monotonic()-start,1)
  (dest/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result),flush=True)
 return result
with ThreadPoolExecutor(max_workers=args.workers) as pool:
 results=[f.result() for f in as_completed([pool.submit(run,n) for n in args.cases])]
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')

