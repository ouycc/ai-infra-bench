import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import time

WORKTREE = Path('/tmp/ai-infra-pr75-update')
TASK = WORKTREE / 'tasks/vllm-async-pp-token-handoff'
IMAGE = 'sha256:cf04408e8aed807333ff1522f952182aa7948f2a32e3caeee79dac9b95911e69'
BASE = '8ebf372e9d612a325f54aadf5c0c3c6588b6afa3'
ORIGINAL = Path('/data/ai-infra-evals/vllm-async-pp-deepseek-allowlist-20260913T040603Z/jobs')
STAMP = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
ROOT = Path('/data/ai-infra-evals') / f'vllm-async-pp-verifier-fix-replay-{STAMP}'


def capture(argv):
    return subprocess.check_output(argv, text=True).strip()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def fingerprint(repo):
    head = capture(['git', '-C', str(repo), 'rev-parse', 'HEAD'])
    changed = subprocess.check_output(['git', '-C', str(repo), 'diff', '--name-only', '-z', 'HEAD']).decode().split('\0')
    untracked = subprocess.check_output(['git', '-C', str(repo), 'ls-files', '--others', '--exclude-standard', '-z']).decode().split('\0')
    paths = sorted(set(filter(None, changed + untracked)))
    return {'head': head, 'files': {f: digest(repo / f) for f in paths},
            'status': capture(['git', '-C', str(repo), 'status', '--porcelain']),
            'diff_sha256': hashlib.sha256(subprocess.check_output(['git', '-C', str(repo), 'diff', '--binary', 'HEAD'])).hexdigest()}


def replay(number, trial, devices):
    repo = ORIGINAL / f'deepseek-{number}' / trial / 'artifacts/repo'
    dest = ROOT / f'deepseek-{number}'
    dest.mkdir()
    name = f'async-pp-verifier-fix-ds{number}-{STAMP.lower()}'
    before = fingerprint(repo)
    assert before['head'] == BASE, before['head']
    write(dest / 'original-identity.json', {'repo': str(repo), **before})
    overlay = dest / 'candidate-overlay.tar'
    with tarfile.open(overlay, 'w') as archive:
        for relative in before['files']:
            archive.add(repo / relative, arcname=relative, recursive=False)
    run_command = ['docker', 'run', '-d', '--name', name, '--network', 'none',
                   '--gpus', f'"device={devices}"', '--cpus', '8', '--memory', '32g',
                   '--shm-size', '2g', '-v', f'{ROOT / "tests"}:/tests:ro', IMAGE]
    entry = ['docker', 'exec', '-u', 'root', name, 'bash', '/tests/test.sh']
    result = {'trial': trial, 'image': IMAGE, 'gpu_devices': devices,
              'network': 'none', 'api_calls': False, 'run_command': run_command,
              'entrypoint': entry, 'started_at': utc()}
    created = False
    began = time.monotonic()
    try:
        result['container_id'] = capture(run_command)
        created = True
        subprocess.run(['docker', 'cp', str(overlay), f'{name}:/tmp/candidate-overlay.tar'], check=True, capture_output=True)
        subprocess.run(['docker', 'exec', '-u', 'agent', name, 'tar', '--no-same-owner', '-xf', '/tmp/candidate-overlay.tar', '-C', '/workspace/repo'], check=True, capture_output=True)
        remote_hash_script = 'import json,hashlib,pathlib; fs=' + repr(list(before['files'])) + '; print(json.dumps({f:hashlib.sha256((pathlib.Path("/workspace/repo")/f).read_bytes()).hexdigest() for f in fs}))'
        copied = json.loads(capture(['docker', 'exec', '-u', 'agent', name, 'python3', '-c', remote_hash_script]))
        assert copied == before['files'], 'candidate transfer hash mismatch'
        result['candidate_transfer_verified'] = True
        write(dest / 'launch.json', result)
        print(json.dumps({'event': 'launched', 'run': number, 'container': name, 'gpu_devices': devices, 'time': utc()}), flush=True)
        with (dest / 'entry.log').open('w') as log:
            process = subprocess.run(entry, stdout=log, stderr=subprocess.STDOUT, timeout=1850)
        result['entry_exit_code'] = process.returncode
        subprocess.run(['docker', 'cp', f'{name}:/logs/verifier', str(dest / 'verifier')], check=True, capture_output=True)
        result['reward'] = (dest / 'verifier/reward.txt').read_text().strip()
        result['stages'] = json.loads((dest / 'verifier/stages.json').read_text())
        failure = dest / 'verifier/failure-stage.txt'
        result['failure_stage'] = failure.read_text().strip() if failure.exists() else None
        e2e = dest / 'verifier/mp-e2e.json'
        if e2e.exists():
            result['mp_e2e_evidence'] = str(e2e)
    except Exception as exc:
        result['replay_error'] = f'{type(exc).__name__}: {exc}'
        if created:
            subprocess.run(['docker', 'cp', f'{name}:/logs/verifier', str(dest / 'verifier')], capture_output=True)
    finally:
        result['finished_at'] = utc()
        result['seconds'] = round(time.monotonic() - began, 3)
        result['original_artifact_unchanged'] = fingerprint(repo) == before
        if created:
            cleanup = subprocess.run(['docker', 'rm', '-f', name], capture_output=True, text=True)
            result['container_removed'] = cleanup.returncode == 0
        write(dest / 'result.json', result)
        print(json.dumps({'event': 'completed', 'run': number, **result}), flush=True)
    return result


ROOT.mkdir()
shutil.copytree(TASK / 'tests', ROOT / 'tests', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
for filename in ('instruction.md', 'task.toml'):
    shutil.copy2(TASK / filename, ROOT / filename)
identity = {
    'worktree': str(WORKTREE),
    'branch': capture(['git', '-C', str(WORKTREE), 'branch', '--show-current']),
    'head': capture(['git', '-C', str(WORKTREE), 'rev-parse', 'HEAD']),
    'dirty_state': capture(['git', '-C', str(WORKTREE), 'status', '--porcelain']),
    'base_commit': BASE, 'image': IMAGE, 'created_at': utc(),
    'semantic_boundary': 'requests -> real scheduler, mp Workers, NCCL GPU token handoff and model execution -> subsequent inputs and collected output tokens',
    'scope': 'Two verifier fixes; regrade both unchanged DeepSeek submissions through /tests/test.sh. No agent or API run. No new Harbor or full-control matrix claim.',
    'skill_files_sha256': {str(p.relative_to(WORKTREE)): digest(p) for p in [
        WORKTREE / '.agents/skills/ai-infra-bench-task-review/SKILL.md',
        WORKTREE / '.agents/skills/ai-infra-bench-task-review/references/review-rubric.md',
        WORKTREE / '.agents/skills/ai-infra-bench-task-review/references/validation-playbook.md']},
    'tests_sha256': {str(p.relative_to(ROOT)): digest(p) for p in sorted((ROOT / 'tests').rglob('*')) if p.is_file()},
    'executable_sha256': {str(p.relative_to(TASK)): digest(p) for p in sorted(TASK.rglob('*')) if p.is_file() and p.relative_to(TASK).parts[0] != 'validation' and '__pycache__' not in p.parts},
}
write(ROOT / 'identity.json', identity)
(ROOT / 'verifier-fix.patch').write_bytes(subprocess.check_output(['git', '-C', str(WORKTREE), 'diff', '--', 'tasks/vllm-async-pp-token-handoff/tests/verify_async_pp.py']))
shutil.copy2(__file__, ROOT / 'replay.py')
Path('/tmp/async-pp-latest-verifier-replay-root').write_text(str(ROOT) + '\n')
print(json.dumps({'event': 'started', 'root': str(ROOT)}), flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
    futures = [executor.submit(replay, 1, 'task__tSxj9V4', '0,2'), executor.submit(replay, 2, 'task__wyoVBcd', '5,6')]
    results = [future.result() for future in futures]
write(ROOT / 'summary.json', results)
