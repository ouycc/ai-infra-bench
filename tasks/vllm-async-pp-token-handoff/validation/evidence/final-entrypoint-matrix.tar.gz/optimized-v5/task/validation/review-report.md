# Async PP behavior hardening

Status: implementation and validation in progress; not an approval. Version 1.2.4 review and execution claims are archived under history/v1.2.4-before-behavior-hardening and do not apply to this revision.

The task statement now specifies mp, two PP stages, ordinary single-token decoding, chunked prefill, completion/compaction and overlapping output collection. Fixed mapping and sentinel assertions were removed. The reference patch includes backports of the all-prefill broadcast skip, non-final-only receive guard, and prompt-buffer extent preservation.

Tests include real scheduler output closure, production next-forward inputs after compaction, causally ordered prefill progress, idle rounds and synchronous regression. The root-owned GPU peer verifies actual payloads in both transport directions against fresh values. The observer checks implicit CUDA runtime synchronization inside the measured handoff after warming communicator initialization.

Final Base, Oracle, historical Oracle, negative controls, a representation-distinct correct alternative, stability and Harbor results are pending. Do not infer acceptance from earlier version evidence or preliminary probes.
