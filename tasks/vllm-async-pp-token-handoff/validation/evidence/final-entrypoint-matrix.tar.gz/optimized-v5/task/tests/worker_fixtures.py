"""Real runner initialization with deterministic model-output inputs.

The production constructor, execute_model, buffers, InputBatch, bookkeeping and
next-input preparation execute unchanged. Model weights and attention computation are not
needed to exercise sampled-token transport. No candidate-private attributes are
invented by this fixture.
"""
import os
from pathlib import Path
from types import SimpleNamespace
from weakref import WeakKeyDictionary
from contextlib import nullcontext

import torch

from vllm.config import CacheConfig, ModelConfig, ParallelConfig, SchedulerConfig, VllmConfig, set_current_vllm_config
from vllm.sampling_params import SamplingParams
from vllm.v1.kv_cache_interface import KVCacheConfig
from vllm.v1.worker.gpu_input_batch import CachedRequestState
from vllm.v1.worker.gpu_model_runner import GPUModelRunner


# Test-owned provenance, independent of candidate event attribute names.
PRIOR_INPUT_EVENTS = WeakKeyDictionary()
NEXT_STEP_FACTS = WeakKeyDictionary()
MODEL_INPUTS = WeakKeyDictionary()

def initialize_runner_groups(rank, world_size):
    """Initialize production world/TP/PP groups on the existing NCCL world."""
    from vllm.distributed.parallel_state import (
        get_pp_group, init_distributed_environment, initialize_model_parallel,
    )
    init_distributed_environment(
        world_size=world_size, rank=rank, distributed_init_method="env://",
        local_rank=int(os.environ["LOCAL_RANK"]), backend="nccl",
    )
    initialize_model_parallel(tensor_model_parallel_size=1,
                              pipeline_model_parallel_size=world_size, backend="nccl")
    return get_pp_group()


def make_runner(req_ids, discard_mask, prior_outputs, sampled=None, *, prompts=None, computed=None, async_mode=True):
    device = torch.device("cuda", int(os.environ.get("LOCAL_RANK", "0")))
    model_config = ModelConfig(
        model=str(Path(__file__).parent / "fixtures/opt-125m"),
        dtype="float16", seed=42, max_model_len=64,
        skip_tokenizer_init=True, enforce_eager=True,
    )
    config = VllmConfig(
        model_config=model_config,
        cache_config=CacheConfig(block_size=16, swap_space=0,
                                 enable_prefix_caching=False),
        scheduler_config=SchedulerConfig(
            max_num_seqs=16, max_num_batched_tokens=64, max_model_len=64,
            is_encoder_decoder=False, async_scheduling=async_mode,
        ),
        parallel_config=ParallelConfig(pipeline_parallel_size=2,
                                       distributed_executor_backend="mp"),
    )
    with set_current_vllm_config(config):
        runner = GPUModelRunner(config, device)
    # No attention is executed. This is the post-cache-setup input to the
    # sampled-token lifecycle; keep the constructor's real InputBatch/buffers.
    runner.kv_cache_config = KVCacheConfig(
        num_blocks=1, kv_cache_tensors=[], kv_cache_groups=[])
    runner.input_ids.cpu.fill_(17)
    for index, req_id in enumerate(req_ids):
        request = CachedRequestState(
            req_id=req_id, prompt_token_ids=(prompts[req_id] if prompts else list(range(8))), mm_features=[],
            sampling_params=SamplingParams(temperature=0, max_tokens=16),
            generator=None, block_ids=([0],),
            num_computed_tokens=(computed[req_id] if computed else 8 + len(prior_outputs[req_id]) - 1 - int(discard_mask[index])),
            output_token_ids=list(prior_outputs[req_id]),
        )
        runner.requests[req_id] = request
        runner.input_batch.add_request(request)
    runner.input_batch.refresh_metadata()
    # Replace only model arithmetic. All preparation and execute/sample state
    # transitions run through the candidate's production implementation.
    from vllm.sequence import IntermediateTensors
    from vllm.distributed.parallel_state import get_pp_group

    class FixedModel(torch.nn.Module):
        def forward(self, input_ids, positions, intermediate_tensors, inputs_embeds):
            # Observe the consumer argument, not a particular runner buffer.
            MODEL_INPUTS[runner] = (input_ids.clone(), tuple(runner.input_batch.req_ids))
            hidden = torch.zeros((len(positions), 1), device=device)
            if not get_pp_group().is_last_rank:
                return IntermediateTensors({"hidden_states": hidden})
            return hidden

        def compute_logits(self, hidden):
            logits = torch.full((len(hidden), 1024), -100.0, device=device)
            if sampled is not None:
                # Control model arithmetic, not a candidate-private sampling
                # helper. The real sampler selects these unambiguous maxima.
                rows = [req_ids.index(r) for r in runner.input_batch.req_ids[:len(hidden)]]
                selected = sampled.index_select(0, torch.tensor(rows, device=device))
                logits.scatter_(1, selected.to(dtype=torch.int64), 100.0)
            return logits

    runner.model = FixedModel()
    runner.intermediate_tensors = IntermediateTensors({
        "hidden_states": torch.zeros((64, 1), device=device),
    })
    scheduler_output = SimpleNamespace(
        finished_req_ids=set(), free_encoder_mm_hashes=[], scheduled_new_reqs=[],
        preempted_req_ids=set(), scheduled_encoder_inputs={},
        num_common_prefix_blocks=[], scheduled_spec_decode_tokens={},
        total_num_scheduled_tokens=len(req_ids),
        num_scheduled_tokens={req_id: 1 for req_id in req_ids},
        scheduled_cached_reqs=SimpleNamespace(
            req_ids=list(req_ids), resumed_req_ids=set(),
            num_computed_tokens=[runner.requests[r].num_computed_tokens for r in req_ids],
            new_block_ids=[None] * len(req_ids),
            # No new CPU tokens in this cached batch. Keep the per-request
            # container valid for both the frozen Base and async implementations.
            new_token_ids=[[] for _ in req_ids],
            num_output_tokens=[len(prior_outputs[r]) for r in req_ids],
        ),
    )
    with set_current_vllm_config(config):
        output = runner.execute_model(scheduler_output, runner.intermediate_tensors)
    if get_pp_group().is_last_rank:
        assert output is None, "last rank must defer sampling after execute_model"
    else:
        assert isinstance(output, IntermediateTensors)
    NEXT_STEP_FACTS[runner] = {
        req_id: {
            'position': (computed[req_id] if computed else 8 + len(prior_outputs[req_id]) - 1 - int(discard_mask[i])) + 1,
            'output_length': len(prior_outputs[req_id]) + int(not discard_mask[i]),
        }
        for i, req_id in enumerate(req_ids)
    }
    PRIOR_INPUT_EVENTS[runner] = {
        id(value) for value in vars(runner).values()
        if isinstance(value, (torch.Event, torch.cuda.Event)) and value.device is not None
    }
    return runner


def next_inputs(runner, req_ids, *, scheduler_output=None, inspect_cpu=True, observer=None):
    """Complete cached-state update, then consume received tokens on the GPU.

    req_ids gives the next consumer order. If a real scheduler output is supplied
    it crosses this boundary directly; otherwise a valid one-token decode event
    is constructed for the retained requests.
    """
    if scheduler_output is None:
        from lifecycle_cases import cached_step
        facts = NEXT_STEP_FACTS[runner]
        scheduler_output = cached_step(
            req_ids,
            [facts[r]['position'] for r in req_ids],
            [1 for _ in req_ids],
            [facts[r]['output_length'] for r in req_ids],
            finished=set(facts) - set(req_ids),
        )
    # Change the workload's row order, then enter the complete production
    # execution path. Do not call one particular token-copy helper in isolation:
    # a correct implementation may consume pending tokens elsewhere in execute.
    for target, req_id in enumerate(req_ids):
        current = runner.input_batch.req_id_to_index[req_id]
        if current != target:
            runner.input_batch.swap_states(target, current)
    with observer.observe() if observer is not None else nullcontext():
        runner.execute_model(scheduler_output, runner.intermediate_tensors)
    inputs = model_inputs_in_request_order(runner, scheduler_output, req_ids)
    return inputs.cpu().tolist() if inspect_cpu else inputs


def model_inputs_in_request_order(runner, step, req_ids):
    """Canonical view of actual model input; candidate row order is unrestricted."""
    offsets = {}
    offset = 0
    input_ids, row_order = MODEL_INPUTS[runner]
    for req_id in row_order:
        count = step.num_scheduled_tokens[req_id]
        offsets[req_id] = list(range(offset, offset + count))
        offset += count
    indices = [i for req_id in req_ids for i in offsets[req_id]]
    index = torch.tensor(indices, dtype=torch.int64, device=input_ids.device)
    return input_ids.index_select(0, index)


def output_tokens_by_request(output):
    assert len(output.req_ids) == len(output.sampled_token_ids)
    assert len(set(output.req_ids)) == len(output.req_ids)
    return dict(zip(output.req_ids, output.sampled_token_ids))
