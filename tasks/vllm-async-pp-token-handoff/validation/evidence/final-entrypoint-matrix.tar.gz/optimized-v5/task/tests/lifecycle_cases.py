"""Behavioral lifecycle cases using production scheduler interfaces.

Inputs are independent of the candidate's placeholder representation. Only
scheduled work, externally returned tokens, completion and subsequent progress
are assertions; internal counters are not scored.
"""
from collections import deque

from vllm.sampling_params import SamplingParams
from vllm.v1.request import Request
from vllm.v1.outputs import ModelRunnerOutput
from task_fixtures import build_scheduler


def scheduler_lifecycle(model):
    results = []
    for async_mode, pp_size in [(True, 2), (False, 2), (True, 1), (False, 1)]:
        scheduler = build_scheduler(model, async_scheduling=async_mode,
                                    pipeline_parallel_size=pp_size,
                                    max_model_len=128, max_num_seqs=4, max_num_batched_tokens=8)
        prompts = {'short': [31, 32, 33], 'long': list(range(41, 62))}
        limits = {'short': 4, 'long': 7}
        emitted = {key: [] for key in prompts}
        # Simulated arithmetic/sampling uses an independently counted stream;
        # scheduling, accounting and output collection are production code.
        cursors = dict.fromkeys(prompts, 0)
        scheduled_positions = dict.fromkeys(prompts, 0)
        pending = deque()
        for key, prompt in prompts.items():
            scheduler.add_request(Request(request_id=key, prompt_token_ids=prompt,
                sampling_params=SamplingParams(max_tokens=limits[key], ignore_eos=True),
                pooling_params=None, eos_token_id=None))
        rounds = 0
        while scheduler.get_num_unfinished_requests() or pending:
            rounds += 1
            assert rounds <= 80, 'scheduler failed to finish bounded workload'
            step = scheduler.schedule()
            ids = list(step.num_scheduled_tokens)
            samples = []
            for key in ids:
                scheduled_positions[key] += step.num_scheduled_tokens[key]
                if scheduled_positions[key] >= len(prompts[key]):
                    samples.append([101 + 100 * (key == 'long') + cursors[key]])
                    cursors[key] += 1
                else:
                    samples.append([])
            if ids:
                pending.append((step, ModelRunnerOutput(req_ids=ids,
                    req_id_to_index={key:i for i,key in enumerate(ids)},
                    sampled_token_ids=samples)))
            # Keep two batches in flight for async PP; also drain at starvation
            # and completion. A separate re-entry test rejects unnecessary gaps.
            depth = 2 if async_mode and pp_size == 2 else 1
            if pending and (len(pending) >= depth or not ids):
                scheduled, output = pending.popleft()
                returned = scheduler.update_from_output(scheduled, output)
                for batch in returned.values():
                    for item in batch.outputs:
                        emitted[item.request_id].extend(item.new_token_ids)
            elif not ids and not pending:
                raise AssertionError('unfinished requests stranded without work')
        expected = {key: list(range(101 + 100 * (key == 'long'),
                                    101 + 100 * (key == 'long') + limits[key]))
                    for key in prompts}
        assert emitted == expected, (emitted, expected)
        assert not scheduler.schedule().num_scheduled_tokens, 'finished requests rescheduled'
        # A fresh request after draining tests that completed ownership/accounting
        # does not strand a new workload.
        scheduler.add_request(Request(request_id='fresh', prompt_token_ids=[17, 19],
            sampling_params=SamplingParams(max_tokens=1, ignore_eos=True),
            pooling_params=None, eos_token_id=None))
        step = scheduler.schedule()
        assert set(step.num_scheduled_tokens) == {'fresh'}
        scheduler.update_from_output(step, ModelRunnerOutput(req_ids=['fresh'],
            req_id_to_index={'fresh':0}, sampled_token_ids=[[313]]))
        assert scheduler.get_num_unfinished_requests() == 0
        results.append({'async':async_mode, 'pp':pp_size, 'outputs':emitted, 'rounds':rounds})
    return results


def cached_step(req_ids, positions, counts, output_lengths, finished=()):
    """Construct the scheduler-to-worker interface from workload facts."""
    from types import SimpleNamespace
    return SimpleNamespace(
        finished_req_ids=set(finished), free_encoder_mm_hashes=[],
        scheduled_new_reqs=[], preempted_req_ids=set(), scheduled_encoder_inputs={},
        num_common_prefix_blocks=[], scheduled_spec_decode_tokens={},
        total_num_scheduled_tokens=sum(counts),
        num_scheduled_tokens=dict(zip(req_ids, counts)),
        scheduled_cached_reqs=SimpleNamespace(
            req_ids=list(req_ids), resumed_req_ids=set(),
            num_computed_tokens=list(positions), num_output_tokens=list(output_lengths),
            new_block_ids=[None] * len(req_ids), new_token_ids=[[] for _ in req_ids],
        ),
    )


def prepare_chunk(runner, req_ids, positions, counts, output_lengths, finished=()):
    step = cached_step(req_ids, positions, counts, output_lengths, finished)
    # Full production input preparation includes the CPU prompt gather before
    # the GPU sampled-token replacement. Calling only _prepare_input_ids would
    # omit the prompt gather and create a fixture-induced failure.
    runner.execute_model(step, runner.intermediate_tensors)
    from worker_fixtures import model_inputs_in_request_order
    return model_inputs_in_request_order(runner, step, req_ids).cpu().tolist()


def compaction_round(rank, invoke):
    import torch
    from worker_fixtures import make_runner
    prompts = {'finish':list(range(11,19)), 'long':list(range(41,78))}
    ids = list(prompts)
    sampled = torch.tensor([[311],[419]], dtype=torch.int32, device='cuda') if rank == 1 else None
    runner = make_runner(ids, [False, True], dict.fromkeys(ids, []), sampled,
                         prompts=prompts, computed={'finish':7, 'long':2})
    output = invoke(runner, is_sender=(rank == 1))
    if rank == 1:
        output = output.get_output() if hasattr(output, 'get_output') else output
        from worker_fixtures import output_tokens_by_request
        assert output_tokens_by_request(output) == {'finish': [311], 'long': []}
    # Finish the leading row while the tail request still has uncomputed prompt
    # tokens. Production _update_states performs the actual removal/compaction.
    chunks = []
    for position, count, finished in [(3, 34, ['finish'])]:
        actual = prepare_chunk(runner, ['long'], [position], [count], [0], finished)
        expected = prompts['long'][position:position+count]
        assert actual == expected, ('prompt_corrupted_after_compaction', rank, position, actual, expected)
        chunks.extend(actual)
    return {'remaining_prompt':chunks, 'completed_removed':True}


def prefill_progress(rank, invoke):
    import torch
    import torch.distributed as dist
    from datetime import timedelta
    from worker_fixtures import make_runner
    prompts = {'a':list(range(11,35)), 'b':list(range(41,72))}
    ids = list(prompts)
    sampled = torch.tensor([[313],[421]], dtype=torch.int32, device='cuda') if rank == 1 else None
    runner = make_runner(ids, [True, True], dict.fromkeys(ids, []), sampled,
                         prompts=prompts, computed={'a':2,'b':4})
    # Test-only control channel establishes causal order without a speed limit:
    # the last stage will not sample until the earlier stage has returned.
    # Waiting for discarded sampled tokens therefore cannot satisfy this case.
    control = dist.new_group([0,1], backend='gloo', timeout=timedelta(seconds=30))
    signal = torch.tensor([1], dtype=torch.int32)
    if rank == 1:
        try:
            dist.recv(signal, src=0, group=control)
        except RuntimeError as exc:
            raise AssertionError("earlier stage did not advance while final sampling was withheld") from exc
    output = invoke(runner, is_sender=(rank == 1), require_collective=False)
    if rank == 0:
        # Input preparation for the next chunk completes before the last stage
        # is released; this checks useful progress, not merely a function return.
        actual = prepare_chunk(runner, ids, [3,5], [4,6], [0,0])
        assert actual == prompts['a'][3:7] + prompts['b'][5:11], actual
        dist.send(signal, dst=1, group=control)
    else:
        output = output.get_output() if hasattr(output, 'get_output') else output
        from worker_fixtures import output_tokens_by_request
        assert output_tokens_by_request(output) == {'a': [], 'b': []}
    dist.destroy_process_group(control)
    return {'earlier_stage_prepared_next_chunk':True}


def idle_last_stage(rank, invoke):
    from worker_fixtures import make_runner
    from types import SimpleNamespace
    import torch
    # An empty scheduler round is a normal engine event, not a fabricated
    # candidate-private state: execute_model must produce the idle state itself.
    sampled = torch.tensor([[101]],dtype=torch.int32,device='cuda') if rank == 1 else None
    runner = make_runner(['done'], [False], {'done':[]}, sampled)
    invoke(runner, is_sender=rank == 1)
    empty = cached_step([], [], [], [], ['done'])
    output = runner.execute_model(empty, runner.intermediate_tensors)
    # Empty execute_model can return an empty output immediately. sample_tokens
    # is called by the executor in split execute/sample operation.
    result = invoke(runner, is_sender=rank == 1, require_collective=False)
    if result is not None:
        result = result.get_output() if hasattr(result,'get_output') else result
        assert not result.req_ids and not result.sampled_token_ids
    return {'idle_completed':True}


def synchronous_runner(rank, invoke):
    import torch
    from worker_fixtures import make_runner, next_inputs
    ids = ['left','right']
    sampled = torch.tensor([[313],[421]],dtype=torch.int32,device='cuda') if rank == 1 else None
    runner = make_runner(ids, [False,False], dict.fromkeys(ids,[]), sampled, async_mode=False)
    output = runner.sample_tokens(None)
    if rank == 1:
        from worker_fixtures import output_tokens_by_request
        assert output_tokens_by_request(output) == {'left': [313], 'right': [421]}
    step = cached_step(ids[::-1], [8,8], [1,1], [1,1])
    step.scheduled_cached_reqs.new_token_ids = [[421],[313]]
    # Observe the actual next forward input rather than an intermediate copy
    # buffer; synchronous input gathering occurs in execute_model.
    runner.execute_model(step, runner.intermediate_tensors)
    from worker_fixtures import model_inputs_in_request_order
    actual = model_inputs_in_request_order(runner, step, ids).cpu().tolist()
    expected = [313, 421]
    assert actual == expected, ('synchronous_next_input',actual)
    return {'synchronous_outputs_preserved':True}
